package com.ap.assignment.repository;

import com.ap.assignment.domain.InvolvedParty;

public interface InvolvedPartyRepository extends Repository<InvolvedParty, Long> {

}
