package com.ap.assignment.repository;

import com.ap.assignment.domain.Task;

public interface TaskRepository extends Repository<Task, Long> {

}
