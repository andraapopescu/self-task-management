package com.ap.assignment.controller;

import com.ap.assignment.domain.Task;
import com.ap.assignment.domain.Tasks;
import com.ap.assignment.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/tasks")
public class TaskController {

    private TaskService taskService;

    @Autowired
    public TaskController(TaskService taskService) {
        this.taskService = taskService;
    }

    @RequestMapping(value = "/{id}", method = RequestMethod.GET)
    public ResponseEntity<Object> getTaskById(@PathVariable("id") long id) {
        Optional<Task> taskOptional = taskService.getTaskById(id);
        if (taskOptional.isPresent()) {
            return new ResponseEntity<>(taskOptional.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>( "There is no task available with id " + id, HttpStatus.NOT_FOUND);
        }
    }

    @RequestMapping(value = "/all", method = RequestMethod.GET)
    public ResponseEntity<Tasks> getAllTasks() {
        Tasks tasks = taskService.getAllTasks();

        if (tasks.getTasks().isEmpty()) {
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        }

        return new ResponseEntity<>(tasks, HttpStatus.OK);
    }

    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public ResponseEntity<String> addTasks(@RequestBody Tasks tasks) {
        if (taskService.saveTasks(tasks)) {
            return new ResponseEntity<String>("Tasks have been saved!", HttpStatus.CREATED);
        } else {
            return new ResponseEntity<String>("One or more tasks have no name!", HttpStatus.UNPROCESSABLE_ENTITY);
        }
    }


    @RequestMapping(value = "/delete/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<String> deleteTask(@PathVariable("id") long id) {
        Optional<Task> taskOptional = taskService.deleteTask(id);
        if (taskOptional.isPresent()) {
            return new ResponseEntity<>("Task << " + taskOptional.get().getName() + " >> was just deleted!",
                    HttpStatus.OK);
        } else {
            return new ResponseEntity<>("There is no task available with id " + id, HttpStatus.NOT_FOUND);
        }
    }

    @RequestMapping(value = "/update", method = RequestMethod.PUT)
    public ResponseEntity<Object> updateTask(@RequestBody Task task) {
        try {
            Optional<Task> taskOptional = taskService.updateTask(task);
            if (taskOptional.isPresent()) {
                return new ResponseEntity<>(taskOptional.get(), HttpStatus.OK);
            } else {
                return new ResponseEntity<>("The task with id " + task.getId() + " was not found!", HttpStatus.NOT_FOUND);
            }
        } catch (IllegalArgumentException e) {
            return new ResponseEntity<>("The task is invalid because has no name!", HttpStatus.UNPROCESSABLE_ENTITY);
        }
    }

}
