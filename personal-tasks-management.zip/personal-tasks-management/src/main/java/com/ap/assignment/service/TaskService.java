package com.ap.assignment.service;

import com.ap.assignment.domain.Task;
import com.ap.assignment.domain.Tasks;
import com.ap.assignment.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class TaskService {

    private TaskRepository taskRepository;

    @Autowired
    public TaskService(TaskRepository taskRepository) {
        this.taskRepository = taskRepository;
    }

    public Tasks getAllTasks() {
        List<Task> result = (ArrayList<Task>) taskRepository.findAll();

        return result.size() == 0 ? new Tasks() : new Tasks(result);
    }

    public boolean saveTasks(Tasks tasks) {
        if(tasks != null && tasks.getTasks() != null) {
            List<Task> taskList = tasks.getTasks();
            if(areTasksValid(taskList)) {
                taskRepository.saveAll(taskList);
                return true;
            }
        }

        return false;
    }

    public Optional<Task> getTaskById(Long taskId) {
        return taskRepository.findById(taskId);

    }

    public Optional<Task> deleteTask(Long taskId) {
        Optional<Task> task = taskRepository.findById(taskId);

        if (task.isPresent()) {
            taskRepository.delete(task.get());
        }

        return task;
    }

    public Optional<Task> updateTask(Task task) {
        Optional<Task> taskOptional = taskRepository.findById(task.getId());

        if (taskOptional.isPresent()) {
            if(!StringUtils.isEmpty(task.getName())) {
                taskRepository.save(task);
            } else {
                throw new IllegalArgumentException();
            }
        }

        return taskOptional;
    }

    protected boolean areTasksValid(List<Task> tasks) {
        return  tasks.size() != 0 &&
                tasks.stream().filter(task -> StringUtils.isEmpty(task.getName()))
                .map(p -> Boolean.FALSE)
                .findAny()
                .orElse(Boolean.TRUE);
    }

}
