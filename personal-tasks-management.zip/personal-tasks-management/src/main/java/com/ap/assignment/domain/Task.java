package com.ap.assignment.domain;

import javax.persistence.*;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "task")
public class Task {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private long id;

    private String name;
    private Date startingDate;
    private Date dueDate;
    private String location;
    private String description;

    @ManyToMany(cascade = { CascadeType.MERGE })
    @JoinTable(
            name = "TASK_INVOLVED_PARTY_MAPPING",
            joinColumns = { @JoinColumn(name = "task_id") },
            inverseJoinColumns = { @JoinColumn(name = "involved_party_id") }
    )
    Set<InvolvedParty> involvedParties = new HashSet<InvolvedParty>();

    public Task() {

    }

    public Task(String name, Date startingDate, Date dueDate, String location, String description, Set<InvolvedParty> involvedParties) {
        this.name = name;
        this.startingDate = startingDate;
        this.dueDate = dueDate;
        this.location = location;
        this.description = description;
        this.involvedParties = involvedParties;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Date getStartingDate() {
        return startingDate;
    }

    public void setStartingDate(Date startingDate) {
        this.startingDate = startingDate;
    }

    public Date getDueDate() {
        return dueDate;
    }

    public void setDueDate(Date dueDate) {
        this.dueDate = dueDate;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Set<InvolvedParty> getInvolvedParties() {
        return involvedParties;
    }

    public void setInvolvedParties(Set<InvolvedParty> involvedParties) {
        this.involvedParties = involvedParties;
    }

    @Override
    public String toString() {
        return "Task{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", startingDate=" + startingDate +
                ", dueDate=" + dueDate +
                ", location='" + location + '\'' +
                ", description='" + description + '\'' +
                ", involvedParties=" + involvedParties +
                '}';
    }
}
