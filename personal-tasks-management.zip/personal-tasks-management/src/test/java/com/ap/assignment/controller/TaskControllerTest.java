package com.ap.assignment.controller;

import com.ap.assignment.UtilsTest;
import com.ap.assignment.domain.Task;
import com.ap.assignment.domain.Tasks;
import com.ap.assignment.repository.TaskRepository;
import com.ap.assignment.service.TaskService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.util.Date;
import java.util.HashSet;
import java.util.Optional;

import static org.hamcrest.CoreMatchers.is;
import static org.mockito.ArgumentMatchers.any;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

public class TaskControllerTest {

    TaskController taskController;

    @Mock
    TaskService taskService;

    @Mock
    TaskRepository taskRepository;
    ObjectMapper objectMapper;

    Task defaultTask;

    private MockMvc mockMvc;

    @Before
    public void seteUp() {
        MockitoAnnotations.initMocks(this);

        taskController = new TaskController(taskService);

        objectMapper = new ObjectMapper();
        defaultTask = UtilsTest.getDefaultTask();
        mockMvc = MockMvcBuilders
                .standaloneSetup(new TaskController(taskService))
                .build();
    }

    @Test
    public void getAllSuccess() throws Exception {
        String firstTaskName = "First Task";
        String secondTaskName = "Second Task";

        Tasks tasks = UtilsTest.createMockTasks(firstTaskName, secondTaskName);

        Mockito.when(taskService.getAllTasks()).thenReturn(tasks);

        MockHttpServletResponse response =
                mockMvc.perform(
                        get("/tasks/all"))
                        .andExpect(status().isOk()).andReturn().getResponse();

        Tasks tasksFromResponse = objectMapper.readValue(response.getContentAsString(), Tasks.class);

        Assert.assertThat(tasksFromResponse.getTasks().size(), is(2));
        Assert.assertTrue(tasks.getTasks().get(0).getName().equals(firstTaskName));
        Assert.assertTrue(tasks.getTasks().get(1).getName().contains(secondTaskName));
    }


    @Test
    public void getAllNoContent() throws Exception {
        Mockito.when(taskService.getAllTasks()).thenReturn(new Tasks());

        MockHttpServletResponse response =
                mockMvc.perform(
                        get("/tasks/all"))
                        .andExpect(status().isNoContent()).andReturn().getResponse();

    }


    @Test
    public void addTasksWithNoName() throws Exception {
        Tasks tasks = UtilsTest.createMockTasks("", "Second Task");
        String jsonTasks = objectMapper.writeValueAsString(tasks);

        Mockito.when(taskService.saveTasks(any(Tasks.class))).thenReturn(false);

        MockHttpServletResponse response =
                mockMvc.perform(
                        post("/tasks/add").contentType(MediaType.APPLICATION_JSON_VALUE)
                                .content(jsonTasks))
                        .andExpect(status().isUnprocessableEntity()).andReturn().getResponse();

        Assert.assertTrue(response.getContentAsString().equals("One or more tasks have no name!"));

    }

    @Test
    public void addTaskSuccess() throws Exception {
        Tasks tasks = UtilsTest.createMockTasks("First Task", "Second Task");
        String jsonTasks = objectMapper.writeValueAsString(tasks);

        Mockito.when(taskService.saveTasks(any(Tasks.class))).thenReturn(true);

        MockHttpServletResponse response =
                mockMvc.perform(
                        post("/tasks/add").contentType(MediaType.APPLICATION_JSON_VALUE)
                                .content(jsonTasks))
                        .andExpect(status().isCreated()).andReturn().getResponse();

        Assert.assertTrue(response.getContentAsString().equals("Tasks have been saved!"));

    }

    @Test
    public void updateTaskSuccess() throws Exception {
        String jsonTask = objectMapper.writeValueAsString(defaultTask);

        Mockito.when(taskService.updateTask(any(Task.class))).thenReturn(Optional.of(defaultTask));

        MockHttpServletResponse response =
                mockMvc.perform(
                        put("/tasks/update").contentType(MediaType.APPLICATION_JSON_VALUE)
                                .content(jsonTask))
                        .andExpect(status().isOk()).andReturn().getResponse();

        Assert.assertTrue(response.getContentAsString().equals(jsonTask));

    }

    @Test
    public void updateTaskNotFound() throws Exception {
        String jsonTask = objectMapper.writeValueAsString(defaultTask);

        Mockito.when(taskService.updateTask(any(Task.class))).thenReturn(Optional.empty());

        MockHttpServletResponse response =
                mockMvc.perform(
                        put("/tasks/update").contentType(MediaType.APPLICATION_JSON_VALUE)
                                .content(jsonTask))
                        .andExpect(status().isNotFound()).andReturn().getResponse();
    }

    @Test
    public void updateTaskInvalid() throws Exception {
        Task invalidTask = new Task("", new Date(), new Date(), "", "string", new HashSet<>());
        String jsonTask = objectMapper.writeValueAsString(invalidTask);

        Mockito.when(taskService.updateTask(any(Task.class))).thenThrow(IllegalArgumentException.class);

        MockHttpServletResponse response =
                mockMvc.perform(
                        put("/tasks/update").contentType(MediaType.APPLICATION_JSON_VALUE)
                                .content(jsonTask))
                        .andExpect(status().isUnprocessableEntity()).andReturn().getResponse();

        Assert.assertTrue(response.getContentAsString().equals("The task is invalid because has no name!"));

    }

    @Test
    public void deleteTaskSucceess() throws Exception {
        long id = 1;

        Mockito.when(taskService.deleteTask(id)).thenReturn(Optional.of(defaultTask));

        mockMvc.perform(delete("/tasks/delete/" + 1))
                .andExpect(status().isOk()).andReturn().getResponse();
    }

    @Test
    public void deleteTaskNotFound() throws Exception {
        long id = 1;

        Mockito.when(taskService.deleteTask(id)).thenReturn(Optional.empty());

        mockMvc.perform(delete("/tasks/delete/" + 1))
                .andExpect(status().isNotFound()).andReturn().getResponse();
    }


}
