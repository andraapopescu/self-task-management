package com.ap.assignment.service;

import com.ap.assignment.UtilsTest;
import com.ap.assignment.domain.InvolvedParty;
import com.ap.assignment.domain.Task;
import com.ap.assignment.domain.Tasks;
import com.ap.assignment.repository.TaskRepository;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import static org.mockito.ArgumentMatchers.anyLong;


import java.util.*;

public class TaskServiceTest {

    @InjectMocks
    TaskService taskService;

    @Mock
    TaskRepository taskRepository;

    @Before
    public void setUp() {
        MockitoAnnotations.initMocks(this);

        taskService = new TaskService(taskRepository);
    }

    @Test
    public void getAllTasksSuccess() {
        List<Task> taskList = new ArrayList<>();
        taskList.add(UtilsTest.getTaskWithInvolvedParty());

        Mockito.when(taskRepository.findAll()).thenReturn(taskList);

        Tasks tasks = taskService.getAllTasks();
        Set<InvolvedParty> involvedParties = tasks.getTasks().get(0).getInvolvedParties();

        Assert.assertTrue(tasks.getTasks().size() == 1);
        Assert.assertTrue(involvedParties.size() == 2);
    }

    @Test
    public void areTaskValidTrue() {
        Tasks tasks = UtilsTest.createMockTasks("First Task", "Second Task");

        Assert.assertTrue(taskService.areTasksValid(tasks.getTasks()));
    }

    @Test
    public void areTaskValidEmptyList() {
        Assert.assertFalse(taskService.areTasksValid(Collections.emptyList()));
    }

    @Test
    public void areTaskValidOneMissingTaskName() {
        Tasks tasks = UtilsTest.createMockTasks("", "Second Task");

        Assert.assertFalse(taskService.areTasksValid(tasks.getTasks()));
    }

    @Test
    public void areTaskValidNoTaskName() {
        Tasks tasks = UtilsTest.createMockTasks("", null);

        Assert.assertFalse(taskService.areTasksValid(tasks.getTasks()));
    }

    @Test
    public void deleteTaskSuccess() {
        Mockito.when(taskRepository.findById(anyLong())).thenReturn(Optional.of(UtilsTest.getDefaultTask()));

        Optional<Task> task = taskService.deleteTask(1L);
        Assert.assertTrue(task.isPresent());
    }

    @Test
    public void deleteTaskNotFound() {
        Mockito.when(taskRepository.findById(anyLong())).thenReturn(Optional.empty());

        Optional<Task> task = taskService.deleteTask(1L);
        Assert.assertFalse(task.isPresent());
    }

    @Test
    public void updateTaskSuccess() {
        Mockito.when(taskRepository.findById(anyLong())).thenReturn(Optional.of(UtilsTest.getDefaultTask()));

        Optional<Task> task = taskService.updateTask(UtilsTest.getDefaultTask());
        Assert.assertTrue(task.isPresent());
    }

    @Test
    public void updateTaskNotFound() {
        Mockito.when(taskRepository.findById(anyLong())).thenReturn(Optional.empty());

        Optional<Task> task = taskService.updateTask(UtilsTest.getDefaultTask());
        Assert.assertFalse(task.isPresent());
    }

    @Test(expected = IllegalArgumentException.class)
    public void updateTaskInvalid() {
        Task invalidTask = new Task(null, new Date(), new Date(), "string", "string", null);
        Mockito.when(taskRepository.findById(anyLong())).thenReturn(Optional.of(invalidTask));

        taskService.updateTask(invalidTask);
    }

}
