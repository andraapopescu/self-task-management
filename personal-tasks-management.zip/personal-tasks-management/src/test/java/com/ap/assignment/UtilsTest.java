package com.ap.assignment;

import com.ap.assignment.domain.InvolvedParty;
import com.ap.assignment.domain.Task;
import com.ap.assignment.domain.Tasks;

import java.util.Arrays;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

public class UtilsTest {

    public static Tasks createMockTasks(String firstTaskName, String secondTaskName) {
        Task firstTask = new Task(firstTaskName, new Date(), new Date(), "Bucharest",
                "This is a trip", new HashSet<>());
        Task secondTask = new Task(secondTaskName, new Date(), new Date(), "Brasov",
                "This is a shopping list", new HashSet<>());

        return new Tasks(Arrays.asList(firstTask, secondTask));
    }

    public static Task getDefaultTask() {
        return new Task("Test", new Date(), new Date(), "Home", "This is a test", new HashSet<>());
    }

    public static Task getTaskWithInvolvedParty() {
        InvolvedParty involvedParty1 = new InvolvedParty("Friend", "friend@email.com", "1234567");
        InvolvedParty involvedParty2 = new InvolvedParty("Manager", "manager@email.com", "765432");

        Set<InvolvedParty> involvedParties = new HashSet<>();
        involvedParties.addAll(Arrays.asList(involvedParty1, involvedParty2));

        return new Task("Test", new Date(), new Date(), "Home", "This is a test", involvedParties);
    }
}
